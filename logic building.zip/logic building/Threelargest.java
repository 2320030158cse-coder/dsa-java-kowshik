public class Threelargest {
    public static void main(String[] args) {
        int a=5;
       int  b=6;
      int   c=7;
if((a>=b)&&(a>=c)){
    System.out.println("largest is a ");
}
else if
(b>=c){
System.out.println("b is largest ");
}
else {
    System.out.println("c is largest  ");
}
    }
}
