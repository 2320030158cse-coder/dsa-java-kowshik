public class Largest {
    public static void main(String[] args) {
        int a=6;
        int b=9;
        if(a>=b){
            System.out.println("a is largest "+a);
        }else{
            System.out.println("b is largest "+b );
        }
    }
}
