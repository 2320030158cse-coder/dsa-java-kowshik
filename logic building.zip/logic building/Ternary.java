public class Ternary {
    public static void main(String[] args) {
        int markrs=66;
        String rc=(markrs>=33)?"pass":"fail";
System.out.println(rc);

    }
}
