public class Vowel {
    public static void main(String[] args) {
       char ch='a';
        if(ch=='a'||ch=='e'||ch=='i'||ch=='o'||ch=='y'||ch=='A'||ch=='E'||ch=='I'||ch=='O'||ch=='Y'){
System.out.println("these are vowels");
        }else{
            System.out.println("not vowels ");
        }
    }
}
