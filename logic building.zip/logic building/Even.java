public class Even {
    public static void main(String[] args) {
        int n=5;
        if(n%2==0){
            System.out.println("even");
        }else{
            System.out.println("odd");
        }
    }
}
