import java .util.*;
public class Cheking {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);

            int num=sc.nextInt();
if(num>0){
    System.out.println("postive ");
}else if(num<0){
    System.out.println("negative");
}else{
    System.out.println("zero ");
}
        }
    }

